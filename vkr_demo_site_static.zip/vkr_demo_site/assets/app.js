const buildings = [
  {
    id: 'b1',
    address: 'г. Воронеж, ул. Московский проспект, д. 14',
    cadastral: '36:34:0102034:101',
    year: 1986,
    series: 'П-44',
    floors: 9,
    entrances: 4,
    area: 8450.6
  },
  {
    id: 'b2',
    address: 'г. Воронеж, ул. Ломоносова, д. 28',
    cadastral: '36:34:0102034:203',
    year: 1979,
    series: '1-464',
    floors: 5,
    entrances: 3,
    area: 5120.4
  },
  {
    id: 'b3',
    address: 'г. Воронеж, ул. Плехановская, д. 61',
    cadastral: '36:34:0102034:309',
    year: 2008,
    series: 'монолит-кирпич',
    floors: 16,
    entrances: 2,
    area: 14620.1
  }
];

let equipment = [
  {
    id: 'eq1', inventory: 'СТ-ХВС-014-01', type: 'Стояк холодного водоснабжения', buildingId: 'b1', place: 'подъезд 1, этаж 4, кв. 41–45', material: 'полипропилен', diameter: 32, condition: 'good', installed: '2018-09-12', nextService: '2026-07-12', x: 210, y: 160, notes: 'Следов течи нет. Доступ через тех. шкаф.'
  },
  {
    id: 'eq2', inventory: 'КР-ГВС-014-07', type: 'Шаровой кран ГВС', buildingId: 'b1', place: 'подвал, секция Б', material: 'латунь', diameter: 25, condition: 'attention', installed: '2016-04-18', nextService: '2026-07-03', x: 463, y: 270, notes: 'Требуется контроль резьбового соединения.'
  },
  {
    id: 'eq3', inventory: 'КАН-014-02', type: 'Канализационный стояк', buildingId: 'b1', place: 'подъезд 2, этаж 4, кв. 43', material: 'ПВХ', diameter: 110, condition: 'bad', installed: '2009-10-01', nextService: '2026-06-28', x: 690, y: 164, notes: 'Повторные засоры. Рекомендована замена участка.'
  },
  {
    id: 'eq4', inventory: 'ОТ-014-11', type: 'Стояк отопления', buildingId: 'b1', place: 'подъезд 3, этаж 4, кв. 45', material: 'сталь', diameter: 25, condition: 'attention', installed: '2012-08-22', nextService: '2026-07-21', x: 724, y: 372, notes: 'Есть признаки коррозии около муфты.'
  },
  {
    id: 'eq5', inventory: 'ОДПУ-028-01', type: 'Общедомовой прибор учета воды', buildingId: 'b2', place: 'подвал, узел учета', material: 'композит', diameter: 40, condition: 'good', installed: '2022-01-17', nextService: '2026-09-01', x: 455, y: 270, notes: 'Поверка действует.'
  },
  {
    id: 'eq6', inventory: 'ЗДВ-061-05', type: 'Задвижка на вводе', buildingId: 'b3', place: 'ИТП, техническое помещение', material: 'чугун', diameter: 80, condition: 'bad', installed: '2010-03-11', nextService: '2026-06-30', x: 455, y: 270, notes: 'Тугое закрытие. Нужна замена до отопительного сезона.'
  },
  {
    id: 'eq7', inventory: 'НСП-061-02', type: 'Насосная станция подкачки', buildingId: 'b3', place: 'подвал, машинное помещение', material: 'сталь', diameter: 50, condition: 'good', installed: '2021-11-29', nextService: '2026-08-18', x: 210, y: 372, notes: 'Работает штатно.'
  }
];

const conditionMap = {
  good: { label: 'Исправно', className: 'status--good', color: '#16a34a' },
  attention: { label: 'Требует осмотра', className: 'status--attention', color: '#f59e0b' },
  bad: { label: 'Требует замены', className: 'status--bad', color: '#dc2626' }
};

const serviceActions = [
  { date: '28.06.2026', title: 'Осмотр канализационного стояка КАН-014-02', text: 'Проверить участок стояка, зафиксировать состояние, подготовить дефектную ведомость.', priority: 'bad' },
  { date: '30.06.2026', title: 'Замена задвижки ЗДВ-061-05', text: 'Подготовить материалы и согласовать отключение с диспетчерской службой.', priority: 'bad' },
  { date: '03.07.2026', title: 'Контроль шарового крана КР-ГВС-014-07', text: 'Проверить резьбовое соединение и отсутствие подтеканий.', priority: 'attention' },
  { date: '12.07.2026', title: 'Плановый осмотр стояка СТ-ХВС-014-01', text: 'Плановая отметка состояния в журнале инвентаризации.', priority: 'good' },
  { date: '21.07.2026', title: 'Осмотр стояка отопления ОТ-014-11', text: 'Проверить коррозию и подготовить решение до начала отопительного сезона.', priority: 'attention' }
];

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

function getBuilding(id) {
  return buildings.find((b) => b.id === id) || buildings[0];
}

function formatDate(iso) {
  return new Date(iso + 'T00:00:00').toLocaleDateString('ru-RU');
}

function setSection(sectionId) {
  $$('.section').forEach((section) => section.classList.toggle('is-visible', section.id === sectionId));
  $$('.nav__link').forEach((link) => link.classList.toggle('active', link.dataset.section === sectionId));
  document.body.classList.remove('menu-open');
}

function renderStats() {
  const critical = equipment.filter((item) => item.condition === 'bad').length;
  const attention = equipment.filter((item) => item.condition === 'attention').length;
  const totalArea = buildings.reduce((sum, b) => sum + b.area, 0);
  const items = [
    { value: buildings.length, label: 'дома в системе' },
    { value: equipment.length, label: 'объектов оборудования' },
    { value: critical, label: 'требуют замены' },
    { value: Math.round(totalArea).toLocaleString('ru-RU'), label: 'м² жилого фонда' }
  ];

  $('#statsGrid').innerHTML = items.map((item) => `
    <article class="stat">
      <div class="stat__value">${item.value}</div>
      <div class="stat__label">${item.label}</div>
    </article>
  `).join('');

  $('#criticalList').innerHTML = equipment
    .filter((item) => item.condition === 'bad' || item.condition === 'attention')
    .slice(0, 5)
    .map((item) => miniItem(item))
    .join('');

  $('#upcomingList').innerHTML = [...equipment]
    .sort((a, b) => a.nextService.localeCompare(b.nextService))
    .slice(0, 5)
    .map((item) => miniItem(item, true))
    .join('');
}

function miniItem(item, showDate = false) {
  const condition = conditionMap[item.condition];
  return `
    <div class="mini-item">
      <div>
        <strong>${item.type}</strong>
        <span>${item.inventory} · ${getBuilding(item.buildingId).address}</span>
      </div>
      <span class="status ${condition.className}">${showDate ? formatDate(item.nextService) : condition.label}</span>
    </div>
  `;
}

function renderBuildings() {
  $('#buildingCards').innerHTML = buildings.map((building) => {
    const count = equipment.filter((item) => item.buildingId === building.id).length;
    const critical = equipment.filter((item) => item.buildingId === building.id && item.condition === 'bad').length;
    return `
      <article class="building-card">
        <div>
          <h3>${building.address}</h3>
          <p>Кадастровый номер: ${building.cadastral}</p>
        </div>
        <div class="building-card__meta">
          <div class="meta-chip"><span>Год</span><strong>${building.year}</strong></div>
          <div class="meta-chip"><span>Серия</span><strong>${building.series}</strong></div>
          <div class="meta-chip"><span>Этажей</span><strong>${building.floors}</strong></div>
          <div class="meta-chip"><span>Объектов</span><strong>${count}</strong></div>
        </div>
        <span class="badge ${critical ? 'badge--danger' : 'badge--good'}">${critical ? critical + ' критичн.' : 'без критичных'}</span>
      </article>
    `;
  }).join('');
}

function renderFilters() {
  const options = ['<option value="all">Все дома</option>'] + buildings.map((b) => `<option value="${b.id}">${b.address}</option>`);
  $('#buildingFilter').innerHTML = options.join('');
  $('#planBuildingSelect').innerHTML = buildings.map((b) => `<option value="${b.id}">${b.address}</option>`).join('');
}

function getFilteredEquipment() {
  const q = $('#searchInput').value.trim().toLowerCase();
  const building = $('#buildingFilter').value;
  const condition = $('#conditionFilter').value;
  return equipment.filter((item) => {
    const haystack = `${item.inventory} ${item.type} ${item.place} ${item.material} ${item.notes}`.toLowerCase();
    const matchesSearch = !q || haystack.includes(q);
    const matchesBuilding = building === 'all' || item.buildingId === building;
    const matchesCondition = condition === 'all' || item.condition === condition;
    return matchesSearch && matchesBuilding && matchesCondition;
  });
}

function renderEquipmentTable() {
  const rows = getFilteredEquipment().map((item) => {
    const condition = conditionMap[item.condition];
    return `
      <tr>
        <td><strong>${item.inventory}</strong></td>
        <td>${item.type}</td>
        <td>${getBuilding(item.buildingId).address}</td>
        <td>${item.place}</td>
        <td>${item.material} / Ду${item.diameter}</td>
        <td><span class="status ${condition.className}">${condition.label}</span></td>
        <td>${formatDate(item.nextService)}</td>
        <td><button class="link-btn" data-open="${item.id}">Карточка</button></td>
      </tr>
    `;
  }).join('');

  $('#equipmentTable').innerHTML = rows || `<tr><td colspan="8">По выбранным фильтрам ничего не найдено.</td></tr>`;
}

function renderPlan() {
  const buildingId = $('#planBuildingSelect').value || buildings[0].id;
  const layer = $('#markersLayer');
  const items = equipment.filter((item) => item.buildingId === buildingId);
  layer.innerHTML = items.map((item) => {
    const condition = conditionMap[item.condition];
    return `
      <g class="marker" data-plan-id="${item.id}" transform="translate(${item.x}, ${item.y})">
        <circle r="18" fill="${condition.color}"></circle>
        <text text-anchor="middle" y="6" fill="#fff" font-size="18" font-weight="900">!</text>
      </g>
    `;
  }).join('');
  $('#selectedPlanObject').innerHTML = items.length ? 'Нажмите на маркер на плане.' : 'Для выбранного дома в демо-данных нет объектов на плане.';
}

function renderServiceTimeline() {
  $('#serviceTimeline').innerHTML = serviceActions.map((action) => {
    const condition = conditionMap[action.priority];
    return `
      <article class="timeline-item">
        <div class="timeline-date">${action.date}</div>
        <div>
          <strong>${action.title}</strong>
          <p>${action.text}</p>
        </div>
        <span class="status ${condition.className}">${condition.label}</span>
      </article>
    `;
  }).join('');
}

function objectDetails(item) {
  const condition = conditionMap[item.condition];
  return `
    <div class="object-info">
      <span class="status ${condition.className}">${condition.label}</span>
      <h2>${item.type}</h2>
      <dl>
        <dt>Инв. номер</dt><dd>${item.inventory}</dd>
        <dt>Дом</dt><dd>${getBuilding(item.buildingId).address}</dd>
        <dt>Место</dt><dd>${item.place}</dd>
        <dt>Материал</dt><dd>${item.material}</dd>
        <dt>Диаметр</dt><dd>Ду${item.diameter}</dd>
        <dt>Установка</dt><dd>${formatDate(item.installed)}</dd>
        <dt>Следующее ТО</dt><dd>${formatDate(item.nextService)}</dd>
      </dl>
      <p>${item.notes}</p>
    </div>
  `;
}

function openObjectDialog(id) {
  const item = equipment.find((eq) => eq.id === id);
  if (!item) return;
  $('#dialogContent').innerHTML = objectDetails(item);
  $('#objectDialog').showModal();
}

function selectPlanObject(id) {
  const item = equipment.find((eq) => eq.id === id);
  if (!item) return;
  $('#selectedPlanObject').innerHTML = objectDetails(item);
}

function openStubForm(title, type) {
  $('#dialogContent').innerHTML = `
    <h2>${title}</h2>
    <p>В демо-версии форма не сохраняет данные на сервер. Она показывает, как может выглядеть ввод данных в настоящей системе.</p>
    <div class="form-grid">
      <label class="full">Наименование / адрес<input placeholder="Введите значение" /></label>
      <label>Тип<select><option>Стояк ХВС</option><option>Шаровой кран</option><option>Прибор учета</option></select></label>
      <label>Состояние<select><option>Исправно</option><option>Требует осмотра</option><option>Требует замены</option></select></label>
      <label>Диаметр<input placeholder="25" /></label>
      <label>Материал<input placeholder="сталь / латунь / ПВХ" /></label>
      <label class="full">Примечание<input placeholder="Описание состояния" /></label>
    </div>
    <div style="margin-top:16px;display:flex;gap:10px;justify-content:flex-end">
      <button class="btn" value="cancel">Закрыть</button>
      <button class="btn btn--primary" value="ok">Сохранить макет</button>
    </div>
  `;
  $('#objectDialog').showModal();
}

function exportCsv() {
  const header = ['inventory', 'type', 'building', 'place', 'material', 'diameter', 'condition', 'next_service'];
  const rows = getFilteredEquipment().map((item) => [
    item.inventory,
    item.type,
    getBuilding(item.buildingId).address,
    item.place,
    item.material,
    item.diameter,
    conditionMap[item.condition].label,
    formatDate(item.nextService)
  ]);
  const csv = [header, ...rows]
    .map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(';'))
    .join('\n');

  const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'equipment_export_demo.csv';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function bindEvents() {
  $$('.nav__link').forEach((link) => link.addEventListener('click', (event) => {
    event.preventDefault();
    setSection(link.dataset.section);
  }));

  $$('[data-jump]').forEach((btn) => btn.addEventListener('click', () => setSection(btn.dataset.jump)));
  $('#menuBtn').addEventListener('click', () => document.body.classList.toggle('menu-open'));
  $('#searchInput').addEventListener('input', renderEquipmentTable);
  $('#buildingFilter').addEventListener('change', renderEquipmentTable);
  $('#conditionFilter').addEventListener('change', renderEquipmentTable);
  $('#planBuildingSelect').addEventListener('change', renderPlan);
  $('#exportCsvBtn').addEventListener('click', exportCsv);
  $('#addBuildingBtn').addEventListener('click', () => openStubForm('Добавление дома', 'building'));
  $('#addEquipmentBtn').addEventListener('click', () => openStubForm('Добавление оборудования', 'equipment'));

  document.addEventListener('click', (event) => {
    const openBtn = event.target.closest('[data-open]');
    if (openBtn) openObjectDialog(openBtn.dataset.open);

    const marker = event.target.closest('[data-plan-id]');
    if (marker) selectPlanObject(marker.dataset.planId);
  });

  $('#roleSelect').addEventListener('change', (event) => {
    const role = event.target.value;
    const canEdit = ['administrator', 'engineer'].includes(role);
    $('#addBuildingBtn').disabled = !canEdit;
    $('#addEquipmentBtn').disabled = !canEdit;
    $('#addBuildingBtn').title = canEdit ? '' : 'В этой роли доступен только просмотр';
    $('#addEquipmentBtn').title = canEdit ? '' : 'В этой роли доступен только просмотр';
  });
}

function init() {
  renderFilters();
  renderStats();
  renderBuildings();
  renderEquipmentTable();
  renderPlan();
  renderServiceTimeline();
  bindEvents();
}

init();
